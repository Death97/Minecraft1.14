package net.minecraft.server;

class EmptyClass {}
