package net.minecraft.server;

final class CreativeModeTab1 extends CreativeModeTab {

    CreativeModeTab1(int i, String s) {
        super(i, s);
    }
}
