package net.minecraft.server;

final class CreativeModeTab4 extends CreativeModeTab {

    CreativeModeTab4(int i, String s) {
        super(i, s);
    }
}
