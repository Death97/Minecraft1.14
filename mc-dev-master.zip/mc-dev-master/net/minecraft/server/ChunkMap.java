package net.minecraft.server;

public class ChunkMap {

    public byte[] a;
    public int b;
    public int c;

    public ChunkMap() {}
}
