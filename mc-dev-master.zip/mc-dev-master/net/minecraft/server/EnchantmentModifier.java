package net.minecraft.server;

interface EnchantmentModifier {

    void a(Enchantment enchantment, int i);
}
