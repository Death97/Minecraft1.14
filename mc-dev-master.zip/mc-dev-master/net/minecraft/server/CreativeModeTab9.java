package net.minecraft.server;

final class CreativeModeTab9 extends CreativeModeTab {

    CreativeModeTab9(int i, String s) {
        super(i, s);
    }
}
