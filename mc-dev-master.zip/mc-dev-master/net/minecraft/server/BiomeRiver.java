package net.minecraft.server;

public class BiomeRiver extends BiomeBase {

    public BiomeRiver(int i) {
        super(i);
        this.at.clear();
    }
}
