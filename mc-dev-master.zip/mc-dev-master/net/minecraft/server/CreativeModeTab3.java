package net.minecraft.server;

final class CreativeModeTab3 extends CreativeModeTab {

    CreativeModeTab3(int i, String s) {
        super(i, s);
    }
}
