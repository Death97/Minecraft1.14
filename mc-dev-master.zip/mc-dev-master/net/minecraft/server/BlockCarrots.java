package net.minecraft.server;

public class BlockCarrots extends BlockCrops {

    public BlockCarrots() {}

    protected Item i() {
        return Items.CARROT;
    }

    protected Item P() {
        return Items.CARROT;
    }
}
