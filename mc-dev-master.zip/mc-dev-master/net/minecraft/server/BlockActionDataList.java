package net.minecraft.server;

import java.util.ArrayList;

class BlockActionDataList extends ArrayList {

    private BlockActionDataList() {}

    BlockActionDataList(BananaAPI bananaapi) {
        this();
    }
}
