package net.minecraft.server;

final class CreativeModeTab6 extends CreativeModeTab {

    CreativeModeTab6(int i, String s) {
        super(i, s);
    }
}
