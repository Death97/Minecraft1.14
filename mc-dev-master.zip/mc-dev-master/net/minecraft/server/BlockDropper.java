package net.minecraft.server;

public class BlockDropper extends BlockDispenser {

    private final IDispenseBehavior P = new DispenseBehaviorItem();

    public BlockDropper() {}

    protected IDispenseBehavior a(ItemStack itemstack) {
        return this.P;
    }

    public TileEntity a(World world, int i) {
        return new TileEntityDropper();
    }

    protected void dispense(World world, int i, int j, int k) {
        SourceBlock sourceblock = new SourceBlock(world, i, j, k);
        TileEntityDispenser tileentitydispenser = (TileEntityDispenser) sourceblock.getTileEntity();

        if (tileentitydispenser != null) {
            int l = tileentitydispenser.i();

            if (l < 0) {
                world.triggerEffect(1001, i, j, k, 0);
            } else {
                ItemStack itemstack = tileentitydispenser.getItem(l);
                int i1 = world.getData(i, j, k) & 7;
                IInventory iinventory = TileEntityHopper.getInventoryAt(world, (double) (i + Facing.b[i1]), (double) (j + Facing.c[i1]), (double) (k + Facing.d[i1]));
                ItemStack itemstack1;

                if (iinventory != null) {
                    itemstack1 = TileEntityHopper.addItem(iinventory, itemstack.cloneItemStack().a(1), Facing.OPPOSITE_FACING[i1]);
                    if (itemstack1 == null) {
                        itemstack1 = itemstack.cloneItemStack();
                        if (--itemstack1.count == 0) {
                            itemstack1 = null;
                        }
                    } else {
                        itemstack1 = itemstack.cloneItemStack();
                    }
                } else {
                    itemstack1 = this.P.a(sourceblock, itemstack);
                    if (itemstack1 != null && itemstack1.count == 0) {
                        itemstack1 = null;
                    }
                }

                tileentitydispenser.setItem(l, itemstack1);
            }
        }
    }
}
