package net.minecraft.server;

class BananaAPI {}
