package net.minecraft.server;

final class CreativeModeTab11 extends CreativeModeTab {

    CreativeModeTab11(int i, String s) {
        super(i, s);
    }
}
