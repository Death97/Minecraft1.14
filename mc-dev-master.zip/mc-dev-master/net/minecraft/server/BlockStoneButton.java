package net.minecraft.server;

public class BlockStoneButton extends BlockButtonAbstract {

    protected BlockStoneButton() {
        super(false);
    }
}
