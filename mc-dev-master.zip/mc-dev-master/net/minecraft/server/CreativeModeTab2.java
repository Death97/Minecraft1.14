package net.minecraft.server;

final class CreativeModeTab2 extends CreativeModeTab {

    CreativeModeTab2(int i, String s) {
        super(i, s);
    }
}
