package net.minecraft.server;

final class DamageCounter implements Counter {

    DamageCounter() {}
}
