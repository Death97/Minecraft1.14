package net.minecraft.server;

public class BlockHay extends BlockRotatable {

    public BlockHay() {
        super(Material.GRASS);
        this.a(CreativeModeTab.b);
    }
}
