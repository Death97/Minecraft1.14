package net.minecraft.server;

public class BlockLog1 extends BlockLogAbstract {

    public static final String[] M = new String[] { "oak", "spruce", "birch", "jungle"};

    public BlockLog1() {}
}
