package net.minecraft.server;

final class CreativeModeTab5 extends CreativeModeTab {

    CreativeModeTab5(int i, String s) {
        super(i, s);
    }
}
