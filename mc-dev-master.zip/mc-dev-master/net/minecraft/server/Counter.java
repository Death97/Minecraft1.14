package net.minecraft.server;

public interface Counter {}
