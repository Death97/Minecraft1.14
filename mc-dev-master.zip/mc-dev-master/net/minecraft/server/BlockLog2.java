package net.minecraft.server;

public class BlockLog2 extends BlockLogAbstract {

    public static final String[] M = new String[] { "acacia", "big_oak"};

    public BlockLog2() {}
}
