package net.minecraft.server;

final class DistancesCounter implements Counter {

    DistancesCounter() {}
}
