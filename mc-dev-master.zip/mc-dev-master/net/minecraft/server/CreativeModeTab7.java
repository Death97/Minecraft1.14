package net.minecraft.server;

final class CreativeModeTab7 extends CreativeModeTab {

    CreativeModeTab7(int i, String s) {
        super(i, s);
    }
}
