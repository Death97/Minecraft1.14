package net.minecraft.server;

public class BlockSponge extends Block {

    protected BlockSponge() {
        super(Material.SPONGE);
        this.a(CreativeModeTab.b);
    }
}
