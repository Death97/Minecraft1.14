package net.minecraft.server;

class EmptyClassZombie {}
