package net.minecraft.server;

final class CreativeModeTab10 extends CreativeModeTab {

    CreativeModeTab10(int i, String s) {
        super(i, s);
    }
}
