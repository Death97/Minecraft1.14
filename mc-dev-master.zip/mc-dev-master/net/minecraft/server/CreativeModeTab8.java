package net.minecraft.server;

final class CreativeModeTab8 extends CreativeModeTab {

    CreativeModeTab8(int i, String s) {
        super(i, s);
    }
}
