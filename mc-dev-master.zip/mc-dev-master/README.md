mc-dev
======

This repository contains [automatically generated](https://github.com/Bukkit/Bukkit-MinecraftServer/) decompiled sources of a (internally renamed) minecraft_server.jar. The original minecraft_server.jar (and therefor this code) is copyrighted by [Mojang AB](http://www.mojang.com).
